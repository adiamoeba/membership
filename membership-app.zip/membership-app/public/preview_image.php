<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/membership.php';
require_once __DIR__ . '/../includes/pdf_preview.php';

$attachId = (int)($_GET['attach'] ?? 0);
$page = (int)($_GET['page'] ?? -1);

if ($attachId <= 0 || $page < 0) {
    http_response_code(400);
    exit;
}

$attachment = slims_select_one(
    'SELECT attach_id, biblio_id, file_name, file_dir FROM mst_attachment WHERE attach_id = ?',
    [$attachId]
);
if (!$attachment) {
    http_response_code(404);
    exit;
}
$attachment['full_path'] = rtrim(SLIMS_REPO_PATH, '/') . '/' . ltrim($attachment['file_dir'], '/') . '/' . $attachment['file_name'];

$member = current_member();
// Jika member sudah punya akses penuh, tidak perlu batasi (tapi tetap boleh lihat preview)
$allowFull = can_read_full($member, (int)$attachment['biblio_id']);
$rule = get_biblio_membership_rule((int)$attachment['biblio_id']);
$previewPages = (int)($rule['preview_pages'] ?? DEFAULT_PREVIEW_PAGES);

// Server-side enforcement: halaman yang diminta harus dalam batas preview,
// kecuali user memang sudah berhak baca penuh.
if (!$allowFull && $page >= $previewPages) {
    http_response_code(403);
    exit;
}

$images = render_preview_images($attachment, $allowFull ? ($page + 1) : $previewPages);

if (!isset($images[$page]) || !file_exists($images[$page])) {
    http_response_code(404);
    exit;
}

header('Content-Type: image/png');
header('Cache-Control: private, max-age=3600');
readfile($images[$page]);
