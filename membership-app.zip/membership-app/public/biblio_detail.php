<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/membership.php';
require_once __DIR__ . '/../includes/pdf_preview.php';

$biblioId = (int)($_GET['id'] ?? 0);
if (!$biblioId) {
    redirect('biblio_list.php');
}

$biblio = slims_select_one(
    'SELECT biblio_id, title, publish_year, edition FROM mst_biblio WHERE biblio_id = ?',
    [$biblioId]
);
if (!$biblio) {
    redirect('biblio_list.php');
}

$attachment = get_biblio_pdf_attachment($biblioId);
$rule = get_biblio_membership_rule($biblioId);
$member = current_member();
$allowFull = can_read_full($member, $biblioId);
$previewPages = $rule['preview_pages'] ?? DEFAULT_PREVIEW_PAGES;

// ---- Mode streaming file PDF penuh (hanya jika berhak) ----
if (isset($_GET['stream']) && $attachment) {
    if (!$allowFull) {
        http_response_code(403);
        die('Anda belum memiliki akses membership untuk membaca dokumen ini secara penuh.');
    }
    if ($member) {
        $log = db_app()->prepare('INSERT INTO read_logs (member_id, biblio_id, mode) VALUES (?,?,"full")');
        $log->execute([$member['id'], $biblioId]);
    }
    stream_full_pdf($attachment);
}

$previewImages = [];
if ($attachment && !$allowFull) {
    $previewImages = render_preview_images($attachment, (int)$previewPages);
}

$pageTitle = $biblio['title'];
require __DIR__ . '/_header.php';
?>
<a href="biblio_list.php" style="font-size:.85rem;color:var(--muted);">&larr; Kembali ke Koleksi</a>
<h1 style="margin-top:8px;"><?= e($biblio['title']) ?></h1>
<p style="color:var(--muted);">
  <?= $biblio['publish_year'] ? e($biblio['publish_year']) : '' ?>
  <?= $biblio['edition'] ? ' &middot; ' . e($biblio['edition']) : '' ?>
</p>

<?php if (!$attachment): ?>
  <div class="alert alert-error">Judul ini belum memiliki file PDF di SLiMS.</div>
<?php elseif ($allowFull): ?>
  <div class="alert alert-success">Anda memiliki akses penuh untuk membaca dokumen ini.</div>
  <a class="btn" target="_blank" href="biblio_detail.php?id=<?= $biblioId ?>&stream=1">Buka / Unduh PDF Lengkap</a>
<?php else: ?>
  <p style="color:var(--muted);">
    Pratinjau <?= (int)$previewPages ?> halaman pertama tersedia gratis. Untuk membaca
    seluruh dokumen, Anda perlu memiliki membership aktif.
  </p>

  <?php if ($previewImages): ?>
    <div class="preview-pages">
      <?php foreach ($previewImages as $i => $img): ?>
        <img src="preview_image.php?attach=<?= (int)$attachment['attach_id'] ?>&page=<?= $i ?>" alt="Halaman <?= $i + 1 ?>">
      <?php endforeach; ?>
    </div>
  <?php elseif (!pdf_is_previewable()): ?>
    <div class="alert alert-error">
      Server belum mendukung render pratinjau (ekstensi PHP Imagick belum aktif).
      Hubungi administrator.
    </div>
  <?php endif; ?>

  <div class="locked-banner">
    <p style="margin:0 0 10px;">🔒 <span class="amber">Konten selebihnya terkunci</span></p>
    <p style="margin:0 0 16px;color:var(--paper-dim);font-size:.9rem;">
      Berlangganan membership untuk membaca dokumen ini sampai selesai.
    </p>
    <?php if ($member): ?>
      <a class="btn" href="subscribe.php">Pilih Paket Membership</a>
    <?php else: ?>
      <a class="btn" href="register.php">Daftar / Masuk untuk Berlangganan</a>
    <?php endif; ?>
  </div>
<?php endif; ?>

<?php require __DIR__ . '/_footer.php'; ?>
