<?php
require_once __DIR__ . '/functions.php';

/**
 * Ambil data attachment (file PDF) pertama milik sebuah biblio dari SLiMS.
 * Skema mst_attachment standar SLiMS 9.x kurang lebih:
 *   attach_id, biblio_id, file_name, file_dir, file_size, file_type
 * Sesuaikan nama kolom jika versi SLiMS Anda sedikit berbeda.
 */
function get_biblio_pdf_attachment(int $biblioId): ?array
{
    $row = slims_select_one(
        "SELECT attach_id, biblio_id, file_name, file_dir
         FROM mst_attachment
         WHERE biblio_id = ? AND file_name LIKE '%.pdf'
         ORDER BY attach_id ASC LIMIT 1",
        [$biblioId]
    );
    if (!$row) {
        return null;
    }
    $row['full_path'] = rtrim(SLIMS_REPO_PATH, '/') . '/' . ltrim($row['file_dir'], '/') . '/' . $row['file_name'];
    return $row;
}

function pdf_is_previewable(): bool
{
    return extension_loaded('imagick');
}

/**
 * Render (dengan cache) N halaman pertama sebuah PDF menjadi file PNG.
 * Return array path gambar (relatif ke storage/preview_cache) yang bisa
 * dialirkan lewat public/preview_image.php.
 */
function render_preview_images(array $attachment, int $pageCount): array
{
    $cacheDir = rtrim(PREVIEW_CACHE_DIR, '/') . '/' . $attachment['attach_id'];
    if (!is_dir($cacheDir)) {
        mkdir($cacheDir, 0755, true);
    }

    $images = [];
    $needsRender = false;
    for ($i = 0; $i < $pageCount; $i++) {
        $target = $cacheDir . "/page-{$i}.png";
        $images[] = $target;
        if (!file_exists($target)) {
            $needsRender = true;
        }
    }

    if ($needsRender && pdf_is_previewable() && file_exists($attachment['full_path'])) {
        try {
            $imagick = new Imagick();
            $imagick->setResolution(120, 120);
            // "[0-N]" membaca hanya rentang halaman yang dibutuhkan, tidak
            // pernah membuka/meng-copy seluruh isi PDF ke luar rentang preview.
            $imagick->readImage($attachment['full_path'] . '[0-' . ($pageCount - 1) . ']');
            foreach ($imagick as $index => $page) {
                $page->setImageFormat('png');
                $page->writeImage($cacheDir . "/page-{$index}.png");
            }
            $imagick->clear();
        } catch (Exception $e) {
            // Gagal render (mis. PDF kurang dari N halaman) -> abaikan,
            // gambar yang berhasil dibuat tetap dipakai.
        }
    }

    // Hanya kembalikan gambar yang benar-benar berhasil dibuat
    return array_values(array_filter($images, 'file_exists'));
}

/**
 * Alirkan file PDF asli ke browser. WAJIB dipanggil hanya setelah
 * can_read_full() bernilai true di pemanggilnya.
 */
function stream_full_pdf(array $attachment): void
{
    if (!file_exists($attachment['full_path'])) {
        http_response_code(404);
        die('File tidak ditemukan.');
    }
    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="' . basename($attachment['full_path']) . '"');
    header('Content-Length: ' . filesize($attachment['full_path']));
    header('X-Content-Type-Options: nosniff');
    readfile($attachment['full_path']);
    exit;
}
